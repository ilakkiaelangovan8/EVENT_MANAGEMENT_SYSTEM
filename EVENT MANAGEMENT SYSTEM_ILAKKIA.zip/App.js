import React, { useState, useEffect } from 'react';
import { Button, TextField, Typography } from '@mui/material';
import EventForm from './components/EventForm';

function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);

  useEffect(() => {
    // Fetch existing events from the backend
    fetch('http://localhost:3001/api/events')  // Port should match backend
      .then(response => response.json())
      .then(data => setEvents(data))
      .catch(error => console.error('Error fetching events:', error));
  }, []);

  const handleDeleteEvent = (eventId) => {
    fetch(`http://localhost:3001/api/events/${eventId}`, {
      method: 'DELETE',
    })
      .then(() => setEvents(events.filter(event => event._id !== eventId)))
      .catch(error => console.error('Error deleting event:', error));
  };

  const handleCreateEvent = (newEvent) => {
    fetch('http://localhost:3001/api/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newEvent)
    })
      .then(response => response.json())
      .then(data => setEvents([...events, data]))
      .catch(error => console.error('Error creating event:', error));
  };

  const handleViewEventDetails = (event) => setSelectedEvent(event);

  return (
    <div style={{ padding: '20px' }}>
      <Typography variant="h3">Event Management System</Typography>
      <EventForm onCreateEvent={handleCreateEvent} />
      <div style={{ marginTop: '20px' }}>
        {events.map(event => (
          <div key={event._id}>
            <Typography variant="h5">{event.title}</Typography>
            <p>{event.description}</p>
            <p>{event.date}</p>
            <Button variant="contained" color="secondary" onClick={() => handleDeleteEvent(event._id)}>Delete</Button>
            <Button variant="contained" color="primary" onClick={() => handleViewEventDetails(event)}>View Details</Button>
          </div>
        ))}
      </div>
      {selectedEvent && (
        <div>
          <Typography variant="h4">Event Details</Typography>
          <p>Title: {selectedEvent.title}</p>
          <p>Description: {selectedEvent.description}</p>
          <p>Date: {selectedEvent.date}</p>
        </div>
      )}
    </div>
  );
}

export default App;
