import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';

function EventForm({ onCreateEvent }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEvent = { title, description, date };
    onCreateEvent(newEvent);
    setTitle('');
    setDescription('');
    setDate('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField label="Event Title" value={title} onChange={(e) => setTitle(e.target.value)} fullWidth margin="normal" />
      <TextField label="Event Description" value={description} onChange={(e) => setDescription(e.target.value)} fullWidth margin="normal" />
      <TextField label="Event Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} fullWidth margin="normal" />
      <Button type="submit" variant="contained" color="primary">Create Event</Button>
    </form>
  );
}

export default EventForm;
