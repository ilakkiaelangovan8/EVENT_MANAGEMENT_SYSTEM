/for global styles /
body {
  font-family: 'Roboto', sans-serif;
  background-color: #f5f5f5;
  margin: 0;
  padding: 20px;
}

h3 {
  color: #3f51b5;
}

button {
  margin-right: 10px;
}
